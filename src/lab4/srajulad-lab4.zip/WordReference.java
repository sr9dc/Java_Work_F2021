// srajulad, Sai Rajuladevi
package lab4;

public abstract class WordReference {
	String[][] wordData;
	abstract String[] lookup(String word);

}
