// Sai Rajuladevi, srajulad

package exam2;

public interface Downloadable {
	public static final int INTERNET_SPEED = 40;
	abstract int  download();
}
